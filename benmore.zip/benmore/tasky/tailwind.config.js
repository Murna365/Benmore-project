module.exports = {
  content: [
    './templates/**/*.html', // All HTML files in the templates directory
    './static/js/**/*.js',  // All JS files in the static/src directory
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}

