# Task Management Dashboard

## Setup Instructions

1. Clone the repository:
   ```sh
   git clone https://github.com/yourusername/task_management.git
   cd task_management
