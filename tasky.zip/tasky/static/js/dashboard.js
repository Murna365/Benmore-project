$(document).ready(function() {
    function loadTasks(status) {
        $.ajax({
            url: `/tasks/api/tasks/${status}/`,
            method: 'GET',
            success: function(data) {
                let taskList = '';
                data.forEach(task => {
                    taskList += `<div class="task">${task.title} - ${task.status}</div>`;
                });
                $('#taskList').html(taskList);
            }
        });
    }

    $('#addTaskBtn').click(function() {
        $('#taskModal').removeClass('hidden');
    });

    $('#closeModal').click(function() {
        $('#taskModal').addClass('hidden');
    });

    // Load tasks initially
    loadTasks('In Progress');
});
