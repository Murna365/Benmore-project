$('#taskForm').submit(function(e) {
    e.preventDefault();
    $.ajax({
        url: '/tasks/task/new/',
        method: 'POST',
        data: $(this).serialize(),
        success: function(response) {
            $('#taskModal').addClass('hidden');
            loadTasks('In Progress');
        }
    });
});
