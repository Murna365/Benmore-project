// static/js/scripts.js

$(document).ready(function() {
    // Initialize FullCalendar
    $('#calendar').fullCalendar({
        header: {
            left: 'prev,next today',
            center: 'title',
            right: 'month,agendaWeek,agendaDay'
        },
        editable: true,
        events: function(start, end, timezone, callback) {
            $.ajax({
                url: '/api/calendar-events/',  // Adjust the URL to your API endpoint
                dataType: 'json',
                success: function(data) {
                    var events = [];
                    $(data).each(function() {
                        events.push({
                            title: $(this).attr('title'),
                            start: $(this).attr('start'),
                            end: $(this).attr('end')
                        });
                    });
                    callback(events);
                }
            });
        },
        eventDrop: function(event, delta, revertFunc) {
            // Handle event drag & drop
            // Example: Update event in the backend
            $.ajax({
                url: '/api/calendar-events/' + event.id + '/',
                type: 'POST',
                data: {
                    start: event.start.format(),
                    end: event.end.format()
                },
                success: function(response) {
                    // Handle success
                },
                error: function() {
                    revertFunc();
                }
            });
        },
        eventResize: function(event, delta, revertFunc) {
            // Handle event resize
            // Example: Update event in the backend
            $.ajax({
                url: '/api/calendar-events/' + event.id + '/',
                type: 'POST',
                data: {
                    start: event.start.format(),
                    end: event.end.format()
                },
                success: function(response) {
                    // Handle success
                },
                error: function() {
                    revertFunc();
                }
            });
        }
    });
});
