# tests.py
from django.test import TestCase
from django.urls import reverse
from .models import Task

class TaskModelTest(TestCase):
    def setUp(self):
        self.task = Task.objects.create(title="Test Task", description="This is a test task.")

    def test_task_create(self):
        task = Task.objects.get(id=self.task.id)
        self.assertEqual(task.title, "Test Task")
        self.assertEqual(task.description, "This is a test task.")

    def test_task_update(self):
        self.task.title = "Updated Task"
        self.task.save()
        updated_task = Task.objects.get(id=self.task.id)
        self.assertEqual(updated_task.title, "Updated Task")

    def test_task_delete(self):
        task_id = self.task.id
        self.task.delete()
        with self.assertRaises(Task.DoesNotExist):
            Task.objects.get(id=task_id)

class TaskViewTest(TestCase):
    def setUp(self):
        self.task = Task.objects.create(title="Test Task", description="This is a test task.")

    def test_task_list(self):
        response = self.client.get(reverse('task_list'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Test Task")

    def test_task_detail(self):
        response = self.client.get(reverse('task_detail', args=[self.task.id]))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Test Task")

    def test_task_create(self):
        response = self.client.post(reverse('task_create'), {
            'title': 'New Task',
            'description': 'This is a new task.'
        })
        self.assertEqual(response.status_code, 302)  # Redirect after success
        self.assertTrue(Task.objects.filter(title='New Task').exists())

    def test_task_update(self):
        response = self.client.post(reverse('task_update', args=[self.task.id]), {
            'title': 'Updated Task',
            'description': 'This is an updated task.'
        })
        self.assertEqual(response.status_code, 302)  # Redirect after success
        self.task.refresh_from_db()
        self.assertEqual(self.task.title, 'Updated Task')

    def test_task_delete(self):
        response = self.client.post(reverse('task_delete', args=[self.task.id]))
        self.assertEqual(response.status_code, 302)  # Redirect after success
        with self.assertRaises(Task.DoesNotExist):
            Task.objects.get(id=self.task.id)
