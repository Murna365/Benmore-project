from django.urls import path, include
from tasks import views 
from django.contrib.auth import views as auth_views
from .views import CustomLoginView,TaskListByStatusView,api_tasks,task_list_view,api_add_task,api_edit_task,api_delete_task
urlpatterns = [
    
    
    path('tasks/edit/<int:pk>/', api_edit_task, name='api_edit_task'),
    path('tasks/delete/<int:pk>/', api_delete_task, name='api_delete_task'),
    path('tasks/status/<str:status>/', TaskListByStatusView.as_view(), name='tasks-by-status'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('calendar/', views.calendar, name='calendar'),
    path('members/', views.members, name='members'),
    path('tasks/', views.task_list, name='task_list'),
    path('tasks/add/', views.add_task, name='add_task'),
    path('tasks/detail/<int:id>/', views.task_detail, name='task_detail'),
    path('task/new/', views.task_create, name='task_create'),
    path('task/<int:pk>/edit/', views.task_update, name='task_update'),
    path('task/<int:pk>/delete/', views.task_delete, name='task_delete'),
   
    path('login/', CustomLoginView.as_view(), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('api/tasks/', api_tasks, name='api_tasks_all'),
    path('api/tasks/<str:status>/', api_tasks, name='api_tasks_status'),
]
