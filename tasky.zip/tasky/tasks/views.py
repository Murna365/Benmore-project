from django.shortcuts import render, get_object_or_404, redirect
from django.http import JsonResponse
from django.contrib.auth import login, logout, authenticate
from .forms import TaskForm, LoginForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth.views import LoginView
from django.contrib import messages
from .forms import reverse_lazy
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView
from .models import Task
from django.contrib.auth.models import User
import sys
import os
from rest_framework import generics,status
from .serializers import TaskSerializer
from datetime import datetime
from rest_framework.response import Response
from rest_framework.decorators import api_view


# Get the directory containing this file
current_dir = os.path.dirname(os.path.abspath(__file__))
# Get the parent directory, which should be the project root
project_root = os.path.dirname(current_dir)

# Add the project root to the Python path
sys.path.append(project_root)

@login_required
def dashboard(request):
    tasks_in_progress = Task.objects.filter(status='In Progress', assigned_to=request.user)
    tasks_completed = Task.objects.filter(status='Completed', assigned_to=request.user)
    tasks_overdue = Task.objects.filter(status='Overdue', assigned_to=request.user)
    return render(request, 'tasks/dashboard.html', {
        'tasks_in_progress': tasks_in_progress,
        'tasks_completed': tasks_completed,
        'tasks_overdue': tasks_overdue,
    })

@login_required
def task_list(request):
    filter_by = request.GET.get('filter_by')
    sort_by = request.GET.get('sort_by')

    # Filtering tasks
    if filter_by:
        tasks = Task.objects.filter(status=filter_by, assigned_to=request.user)
    else:
        tasks = Task.objects.filter(assigned_to=request.user)

    # Sorting tasks
    if sort_by:
        tasks = tasks.order_by(sort_by)

    # Categorizing tasks
    tasks_in_progress = tasks.filter(status='In Progress')
    tasks_completed = tasks.filter(status='Completed')
    tasks_overdue = tasks.filter(status='Overdue')

    context = {
        'tasks_in_progress': tasks_in_progress,
        'tasks_completed': tasks_completed,
        'tasks_overdue': tasks_overdue,
    }

    return render(request, 'tasks/task_list.html', context)
def calendar(request):
    return render(request, 'calendar.html')

def members(request):
    return render(request, 'members.html')


def task_detail(request, id):
    task = get_object_or_404(Task, id=id)
    return render(request, 'tasks/task_detail.html', {'task': task})
def task_list_view(request):
    return render(request, 'tasks/task_list.html')

def task_create(request):
    if request.method == "POST":
        form = TaskForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('task_list')
    else:
        form = TaskForm()
    return render(request, 'task_form.html', {'form': form})

def task_update(request, id):
    task = get_object_or_404(Task, id=id)
    if request.method == "POST":
        form = TaskForm(request.POST, instance=task)
        if form.is_valid():
            form.save()
            return redirect('task_list')
    else:
        form = TaskForm(instance=task)
    return render(request, 'task_form.html', {'form': form})

def task_delete(request, id):
    task = get_object_or_404(Task, id=id)
    if request.method == "POST":
        task.delete()
        return JsonResponse({'status': 'success'})
    return render(request, 'task_confirm_delete.html', {'task': task})
   


def login_view(request):
    if request.method == "POST":
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('dashboard')
    else:
        form = LoginForm()
    return render(request, 'registration/login.html', {'form': form})

def logout_view(request):
    logout(request)
    return redirect('registration/login.html')

class CustomLoginView(LoginView):
    template_name = 'registration/login.html'
    
    def form_valid(self, form):
        messages.success(self.request, 'You have successfully logged in!')
        return super().form_valid(form)


def view_function():
    from tasks.forms import CustomLoginView  # Absolute import
    login_view = CustomLoginView()
    login_view.login()

if __name__ == "__main__":
    view_function()
    
def members_list(request):
    members = User.objects.annotate(task_count=('task'))
    return render(request, 'members.html', {'members': members})
def add_task(request):
    if request.method == 'POST':
        form = TaskForm(request.POST)
        if form.is_valid():
            task = form.save(commit=False)
            task.assigned_to = request.user
            task.save()
            return redirect('task_list')
    else:
        form = TaskForm()
    return render(request, 'tasks/add_task.html', {'form': form})
class TaskListByStatusView(generics.ListAPIView):
    serializer_class = TaskSerializer

    def get_queryset(self):
        status = self.kwargs['status']
        return Task.objects.filter(status=status)
@api_view(['GET'])
def api_tasks(request, status=None):
    if status == 'in_progress':
        tasks = Task.objects.filter(status='in_progress')
    elif status == 'completed':
        tasks = Task.objects.filter(status='completed')
    elif status == 'overdue':
        tasks = Task.objects.filter(status='overdue')
    else:
        tasks = Task.objects.all()

    serializer = TaskSerializer(tasks, many=True)
    return Response(serializer.data)
@api_view(['POST'])
def api_add_task(request):
    serializer = TaskSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['PUT'])
def api_edit_task(request, pk):
    try:
        task = Task.objects.get(pk=pk)
    except Task.DoesNotExist:
        return Response(status=status.HTTP_404_NOT_FOUND)

    serializer = TaskSerializer(task, data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['DELETE'])
def api_delete_task(request, pk):
    try:
        task = Task.objects.get(pk=pk)
    except Task.DoesNotExist:
        return Response(status=status.HTTP_404_NOT_FOUND)

    task.delete()
    return Response(status=status.HTTP_204_NO_CONTENT)


